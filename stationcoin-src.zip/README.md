RPC Port: 42391
Network Port: 42390